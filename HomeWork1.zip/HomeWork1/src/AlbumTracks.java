
public class AlbumTracks {
	private int AlbumID;
	private int TrackID;
	
	public int GetAlbumID() {
		return AlbumID;
	}
	public void SetAlbumID(int value) {
		AlbumID = value;
	}
	public int GetTrackID() {
		return TrackID;
	}
	public void SetTrackID(int value) {
		TrackID = value;
	}
}

